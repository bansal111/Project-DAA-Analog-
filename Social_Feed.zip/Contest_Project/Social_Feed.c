#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NUM_SUBJECTS 6
#define MAX_TEXT_LEN 256
#define W_PREF     2.0
#define W_RECENCY  3.0
#define W_ENGAGE   1.5
#define W_INTERACT 2.5
#define CURRENT_TIME 2025

const char *subjects[NUM_SUBJECTS] = {"Math", "Science", "Sports", "Tech", "Movies", "News"};

const char *subjectKeywords[NUM_SUBJECTS][3] = {
    {"math", "algebra", "calculus"},
    {"science", "physics", "chemistry"},
    {"sports", "football", "cricket"},
    {"tech", "ai", "robot"},
    {"movies", "film", "cinema"},
    {"news", "politics", "world"}
};

typedef struct Post {
    int postId;
    int authorId;
    char text[MAX_TEXT_LEN];
    int subject;
    int likes, comments, shares;
    int timestamp;
} Post;

typedef struct PostNode {
    Post post;
    struct PostNode *next;
} PostNode;

typedef struct User {
    int userId;
    int preferences[NUM_SUBJECTS];
    int interactions[100];
} User;

typedef struct UserNode {
    User user;
    struct UserNode *next;
} UserNode;

UserNode *userHead = NULL;
PostNode *postHead = NULL;

// Convert the string to lowercase
void toLower(char *str) {
    for (int i = 0; str[i]; i++)
        str[i] = tolower(str[i]);
}

// Detecting the subjects using the keywords defined
int detectSubjectFromText(char *text) {
    char tempText[MAX_TEXT_LEN];
    strcpy(tempText, text);
    toLower(tempText);
    for (int i = 0; i < NUM_SUBJECTS; i++) {
        for (int j = 0; j < 3; j++) {
            if (strstr(tempText, subjectKeywords[i][j])) {
                return i;
            }
        }
    }
    return NUM_SUBJECTS - 1;
}

// Adding the user to the linked list
void addUser(User user) {
    UserNode *newNode = (UserNode *)malloc(sizeof(UserNode));
    newNode->user = user;
    newNode->next = userHead;
    userHead = newNode;
}

// Calculating the score based on timestamp, interaction, subject prefernce
double computeScore(User *user, Post *post) {
    double score = 0.0;
    if (user->preferences[post->subject])
        score += W_PREF;
    double recency = 1.0 / (CURRENT_TIME - post->timestamp + 1);
    score += W_RECENCY * recency;
    int engagement = post->likes + post->comments + post->shares;
    score += W_ENGAGE * engagement;
    score += W_INTERACT * user->interactions[post->authorId];
    return score;
}

//Adding the post and doing the insertion sort
void addPostSorted(Post post, User *user) {
    PostNode *newNode = (PostNode *)malloc(sizeof(PostNode));
    newNode->post = post;
    newNode->next = NULL;

    double newScore = computeScore(user, &newNode->post);

    if (!postHead || computeScore(user, &postHead->post) < newScore) {
        newNode->next = postHead;
        postHead = newNode;
        return;
    }

    PostNode *current = postHead;
    while (current->next && computeScore(user, &current->next->post) >= newScore) {
        current = current->next;
    }

    newNode->next = current->next;
    current->next = newNode;
}

//Reading the users from the file
void readUsers(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Failed to open user file");
        exit(1);
    }
    char line[1024];
    fgets(line, sizeof(line), fp);
    while (fgets(line, sizeof(line), fp)) {
        User u;
        char *token = strtok(line, ",");
        u.userId = atoi(token);
        for (int i = 0; i < NUM_SUBJECTS; i++) {
            token = strtok(NULL, ",");
            u.preferences[i] = atoi(token);
        }
        for (int i = 0; i < 100; i++) {
            token = strtok(NULL, ",");
            if (token)
                u.interactions[i] = atoi(token);
            else
                u.interactions[i] = 0;
        }
        addUser(u);
    }
    fclose(fp);
}

//Reading the posts from the file
void readPosts(const char *filename, User *user) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Failed to open post file");
        exit(1);
    }

    char line[1024];
    fgets(line, sizeof(line), fp);
    while (fgets(line, sizeof(line), fp)) {
        Post p;
        char *token = strtok(line, ",");
        p.postId = atoi(token);
        token = strtok(NULL, ",");
        p.authorId = atoi(token);
        token = strtok(NULL, ",");
        strncpy(p.text, token, MAX_TEXT_LEN);
        p.text[strcspn(p.text, "\n")] = 0;
        p.subject = detectSubjectFromText(p.text);
        token = strtok(NULL, ",");
        p.likes = atoi(token);
        token = strtok(NULL, ",");
        p.comments = atoi(token);
        token = strtok(NULL, ",");
        p.shares = atoi(token);
        token = strtok(NULL, ",");
        p.timestamp = atoi(token);
        addPostSorted(p, user);
    }
    fclose(fp);
}

User *findUserById(int id) {
    UserNode *temp = userHead;
    while (temp) {
        if (temp->user.userId == id)
            return &temp->user;
        temp = temp->next;
    }
    return NULL;
}

void displayFeed(User *user) {
    printf("Personalized Feed for User %d:\n", user->userId);
    PostNode *temp = postHead;
    while (temp) {
        double score = computeScore(user, &temp->post);
        printf("PostID: %d , Author: %d , Subject: %s , Score: %.2f\n", 
            temp->post.postId, temp->post.authorId,
            subjects[temp->post.subject], score);
        printf("Text: %s\nLikes: %d, Comments: %d, Shares: %d, Timestamp: %d\n\n",
            temp->post.text, temp->post.likes, temp->post.comments, temp->post.shares, temp->post.timestamp);
        temp = temp->next;
    }
}

int main() {
    readUsers("G:/DAA/Contest_Project/Data_user.csv");

    int uid;
    printf("Enter your user ID: ");
    scanf("%d", &uid);
    User *u = findUserById(uid);
    if (!u) {
        printf("User ID %d not found.\n", uid);
        return 1;
    }

    readPosts("G:/DAA/Contest_Project/Data_post.csv", u);
    displayFeed(u);
    return 0;
}
