import pandas as pd
import csv
from collections import defaultdict
from collections import deque
import heapq
from datetime import datetime, timedelta

# Path of the File
file_name = r"G:\\DAA\\Flight_route_optimization\\data.csv"
festival_file = r"G:\\DAA\\Flight_route_optimization\\festival.csv"

def parse_time(date_str, time_str):
    try:
        return datetime.strptime(time_str, "%d-%m-%Y %H:%M")
    except ValueError:
        base = datetime.strptime(date_str, "%Y-%m-%d")
        hour, minute = map(int, time_str.split(":"))
        return base + timedelta(hours=hour, minutes=minute)
    
# Loading the Flight Data
def load_flight_data():
    df = pd.read_csv(file_name)
    
    required_columns = ['Origin', 'Destination', 'Flight Price', 'Duration Time', 'Company', 'Date', 'Departure Time', 'Arrival Time', 'Total_Stops', 'seats_booked', 'total_seats']
    df.dropna(subset=required_columns, inplace=True)
    df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
    df['Flight Price'] = df['Flight Price'].astype(str).str.replace(',', '', regex=True).astype(float).astype(int)

    df.reset_index(drop=True, inplace=True)
    df['flight_id'] = df.index

    return df

# Loading the Festivals Date
def load_festival_dates():
    festival_dates = set()
    with open(festival_file, "r", encoding="utf-8") as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            if len(row) >= 4:
                try:
                    festival_date_str = f"{row[2]}-{row[3]}"
                    festival_date = datetime.strptime(festival_date_str, "%b-%d-%Y").date()
                    festival_dates.add(festival_date)
                except ValueError:
                    continue
    return festival_dates

def identify_hub_cities(df):
    city_connections = defaultdict(int)
    for _, row in df.iterrows():
        city_connections[row['Origin']] += 1
        city_connections[row['Destination']] += 1
    avg_connections = sum(city_connections.values()) / len(city_connections)
    return {city for city, count in city_connections.items() if count > avg_connections}

# Applying Dynamic Pricing
def dynamic_pricing(base_price, flight_date, festival_dates, origin, destination, departure_time, seats_left, total_seats):
    if pd.isna(flight_date):
        return base_price

    today = datetime.today().date()
    if isinstance(flight_date, pd.Timestamp):
        flight_date = flight_date.date()
    days_until_flight = (flight_date - today).days
    new_price = base_price

    if days_until_flight <= 7:
        new_price *= 1.15
    elif days_until_flight <= 15:
        new_price *= 1.10

    if flight_date in festival_dates:
        new_price *= 1.20
    if origin in hub_cities or destination in hub_cities:
        new_price *= 0.85

    peak_hours = [(6, 9), (17, 22)]
    flight_hour = int(departure_time.split(':')[0])
    if any(start <= flight_hour <= end for start, end in peak_hours):
        new_price *= 1.10

    seat_utilization = (total_seats - seats_left) / total_seats
    if seat_utilization > 0.9:
        new_price *= 1.30
    elif seat_utilization > 0.7:
        new_price *= 1.20
    elif seat_utilization > 0.5:
        new_price *= 1.10
    elif seat_utilization < 0.3:
        new_price *= 0.85

    return int(new_price)

def find_alternate_path_floyd_warshall(df, source, destination, user_date, preference="price", festival_dates=[]):
    df['Date'] = df['Date'].astype(str)

    all_flights = df[df['Date'] == user_date.strftime("%Y-%m-%d")].copy()
    all_flights['Departure_dt'] = all_flights.apply(lambda r: parse_time(r['Date'], r['Departure Time']), axis=1)
    all_flights['Arrival_dt'] = all_flights.apply(lambda r: parse_time(r['Date'], r['Arrival Time']), axis=1)

    all_flights.loc[all_flights['Arrival_dt'] < all_flights['Departure_dt'], 'Arrival_dt'] += timedelta(days=1)

    routes = []

    def dfs(city, path, total_price, total_duration, last_arrival):
        if city == destination:
            routes.append({
                'path': path.copy(),
                'total_price': total_price,
                'total_duration': total_duration 
            })
            return

        next_flights = all_flights[all_flights['Origin'] == city]
        for _, flight in next_flights.iterrows():
            if flight['flight_id'] in path:
                continue 

            if last_arrival and flight['Departure_dt'] <= last_arrival:
                continue
        
            flight_date = flight['Date']
            if isinstance(flight_date, str):
                try:
                    flight_date = datetime.strptime(flight_date, "%Y-%m-%d").date()
                except ValueError:
                    flight_date = datetime.strptime(flight_date, "%d-%m-%Y").date()

            dynamic_price = dynamic_pricing(
                flight['Flight Price'], flight_date, festival_dates,
                flight['Origin'], flight['Destination'], flight['Departure Time'],
                flight['total_seats'] - flight['seats_booked'], flight['total_seats']
            )
            dfs(
                flight['Destination'],
                path + [flight['flight_id']],
                total_price + dynamic_price,
                total_duration + flight['Duration Time'],
                flight['Arrival_dt']
            )

    dfs(source, [], 0, 0, None)

    if not routes:
        print("No alternate path found.")
        return df

    if preference == "price":
        routes.sort(key=lambda x: x['total_price'])
    else:
        routes.sort(key=lambda x: x['total_duration'])

    print(f"\nTop alternate routes from {source} to {destination}:")
    for i, route in enumerate(routes[:3], 1):
        print(f"\nRoute {i}:")
        for fid in route['path']:
            flight = df[df['flight_id'] == fid].iloc[0]
            print(f"  {flight['Origin']} -> {flight['Destination']} | {flight['Departure Time']} to {flight['Arrival Time']} | Airline: {flight['Company']} | Duration: {flight['Duration Time']} mins | Seats Left: {flight['seats_left']} | Flight ID: {fid}")
        print(f"Total Price: ₹{route['total_price']} | Total Duration: {route['total_duration']} mins")

    choice = input("\nDo you want to book these flights? (yes/no): ").strip().lower()
    if choice == "yes":
        try:
            flight_ids = input("Enter flight IDs separated by space: ").strip().split()
            for fid in flight_ids:
                df = book_seat(df, int(fid))
        except Exception as e:
            print("Error during booking:", e)

    return df

def search_sort_book_flight(df, start_city, end_city, date, festival_dates):
    user_date = datetime.strptime(date, "%Y-%m-%d").date()
    df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d', errors='coerce')
    direct_flights_on_date = df[(df['Origin'] == start_city) &
                                 (df['Destination'] == end_city) &
                                 (df['Date'].dt.date == user_date)].copy()

    if not direct_flights_on_date.empty:
        available_flights = direct_flights_on_date
        print("\nDirect flights found:")
    else:
        print("\nNo direct flights found on the specified date. Searching alternate paths...")
        print("Sort alternate routes by:")
        print("1. Price (Lowest to Highest)")
        print("2. Duration (Shortest to Longest)")
        sort_choice = input("Enter your choice (1 or 2): ").strip()
        preference = "price" if sort_choice == "1" else "duration"
        df_without_direct = df[~((df['Origin'] == start_city) & (df['Destination'] == end_city) & (df['Date'] == user_date))]
        return find_alternate_path_floyd_warshall(df_without_direct, start_city, end_city, user_date, preference, festival_dates)

    available_flights['Dynamic Price'] = available_flights.apply(
        lambda row: dynamic_pricing(row['Flight Price'], row['Date'], festival_dates,
                                    row['Origin'], row['Destination'], row['Departure Time'],
                                    row['total_seats'] - row['seats_booked'], row['total_seats']), axis=1
    )

    print("\nSort flights by:")
    print("1. Price (Lowest to Highest)")
    print("2. Duration (Shortest to Longest)")
    sort_choice = input("Enter your choice (1 or 2): ").strip()

    if sort_choice == "1":
        available_flights = available_flights.sort_values(by="Dynamic Price", ascending=True)
    elif sort_choice == "2":
        available_flights = available_flights.sort_values(by="Duration Time", ascending=True)
    else:
        print("Invalid choice. Showing unsorted flights.")

    print("\nAvailable Flights (Sorted):")
    print(available_flights[['flight_id', 'Origin', 'Destination', 'Company', 'Departure Time',
                                'Arrival Time', 'Flight Price', 'Dynamic Price', 'Duration Time',
                                'seats_booked', 'total_seats']])

    print("\n1. Book a flight")
    print("2. Exit")
    book_choice = input("Enter your choice (1 or 2): ").strip()
    if book_choice == "2":
        return df
    else:
        try:
            flight_id = int(input("\nEnter Flight ID to book: ").strip())
            df = book_seat(df, flight_id)
        except ValueError:
            print("Invalid input! Please enter a numeric Flight ID.")

    return df

# Seat booking
def book_seat(df, flight_id):
    if flight_id not in df['flight_id'].values:
        print("Invalid Flight ID! Please enter a valid one.")
        return df
    df['seats_booked'] = pd.to_numeric(df['seats_booked'], errors='coerce').fillna(0).astype(int)
    df['total_seats'] = pd.to_numeric(df['total_seats'], errors='coerce').fillna(0).astype(int)
    flight_index = df[df['flight_id'] == flight_id].index[0]

    if df.at[flight_index, 'seats_booked'] >= df.at[flight_index, 'total_seats']:
        print("\nSorry, no seats left for this flight.")
        return df

    df.at[flight_index, 'seats_booked'] += 1
    df.at[flight_index, 'seats_left'] = df.at[flight_index, 'total_seats'] - df.at[flight_index, 'seats_booked']

    update_csv(df)  
    print("\nBooking successful! Seat updated.")
    return df

# Updating the CSV if seat is booked
def update_csv(df):
    df.to_csv(file_name, index=False)
    print("\nFlight data updated.")

def build_graph_for_matching(passenger_preferences, flights_df):
    graph = defaultdict(list)
    capacity = defaultdict(int)
    flight_ids = set(flights_df['flight_id'])

    source = 'source'
    sink = 'sink'
    for p_id in passenger_preferences:
        graph[source].append(p_id)
        capacity[(source, p_id)] = 1

    for p_id, prefs in passenger_preferences.items():
        for _, flight in flights_df.iterrows():
            fid = flight['flight_id']
            pref_date = datetime.strptime(prefs['date'], "%Y-%m-%d").date()
            if (prefs['origin'] == flight['Origin'] and
                    prefs['destination'] == flight['Destination'] and
                    pref_date == pd.to_datetime(flight['Date']).date()):
                price_ok = 'price' not in prefs or flight['Flight Price'] <= prefs['price']
                duration_ok = 'duration' not in prefs or flight['Duration Time'] <= prefs['duration']
                departure_time_ok = True

                if 'departure_time' in prefs:
                    departure_hour = int(flight['Departure Time'].split(":")[0])
                    if prefs['departure_time'] == 'morning' and not (6 <= departure_hour < 12):
                        departure_time_ok = False
                    elif prefs['departure_time'] == 'evening' and not (17 <= departure_hour < 22):
                        departure_time_ok = False
                    elif prefs['departure_time'] != 'any' and prefs['departure_time'] not in ['morning', 'evening']:
                        departure_time_ok = False

                if price_ok and duration_ok and departure_time_ok:
                    graph[p_id].append(fid)
                    graph[fid].append(p_id)
                    capacity[(p_id, fid)] = 1
    for fid in flight_ids:
        graph[fid].append(sink)
        capacity[(fid, sink)] = 1

    return graph, capacity, source, sink


def bfs(graph, capacity, source, sink, parent):
    visited = set()
    queue = deque([source])
    visited.add(source)

    while queue:
        u = queue.popleft()
        for v in graph[u]:
            if v not in visited and capacity[(u, v)] > 0:
                visited.add(v)
                parent[v] = u
                if v == sink:
                    return True
                queue.append(v)
    return False

def ford_fulkerson(graph, capacity, source, sink):
    flow = 0
    parent = {}
    match_result = {}

    while bfs(graph, capacity, source, sink, parent):
        path_flow = float('inf')
        s = sink
        while s != source:
            path_flow = min(path_flow, capacity[(parent[s], s)])
            s = parent[s]

        v = sink
        while v != source:
            u = parent[v]
            capacity[(u, v)] -= path_flow
            capacity[(v, u)] += path_flow
            v = parent[v]

        flow += path_flow

    for u in graph:
        for v in graph[u]:
            if capacity[(v, u)] == 1 and isinstance(u, str) and u.startswith("P"):
                match_result[u] = v

    return flow, match_result

def perform_bipartite_flight_allocation(df):
    n = int(input("Enter number of passengers: ").strip())
    passenger_preferences = {}

    for i in range(n):
        print(f"\nEnter details for Passenger {i+1}:")
        origin = input("Origin: ").strip()
        destination = input("Destination: ").strip()
        date = input("Travel Date (YYYY-MM-DD): ").strip()

        price = float(input("Max Price: ").strip()) 
        duration = int(input("Max Duration (in minutes): ").strip())
        departure_time = input("Preferred Departure Time (morning/evening/any): ").strip()

        passenger_preferences[f"P{i+1}"] = {
            'origin': origin,
            'destination': destination,
            'date': date,
            'price': price,
            'duration': duration,
            'departure_time': departure_time 
        }

    filtered_df = df.copy()
    graph, capacity, source, sink = build_graph_for_matching(passenger_preferences, filtered_df)
    flow, match_result = ford_fulkerson(graph, capacity, source, sink)

    print("\nPrice Preferences is based on the base price of flight and not the dynamic price.")
    print(f"\nTotal Allocated Passengers: {flow}/{n}")
    for pid, fid in match_result.items():
        flight = df[df['flight_id'] == fid].iloc[0]
        flight_price = flight['Flight Price']
        flight_date = flight['Date']
        dynamic_price = dynamic_pricing(
            flight['Flight Price'], flight['Date'], festival_dates,
            flight['Origin'], flight['Destination'], flight['Departure Time'],
            flight['seats_left'], flight['total_seats']
        )
        print(f"\n{pid} Assigned to Flight {fid}:")
        print(f"Origin: {flight['Origin']} -> Destination: {flight['Destination']}")
        print(f"Airline: {flight['Company']} | Departure: {flight['Departure Time']} | Arrival: {flight['Arrival Time']}")
        print(f"Original Price: {flight_price} | Dynamic Price: {dynamic_price}")
        confirmation = input(f"Do you want to book this flight at the dynamic price of {dynamic_price}? (yes/no): ").strip().lower()
    
        if confirmation == 'yes':
            df = book_seat(df, fid)
            print(f"Flight {fid} booked for {pid} at {dynamic_price}!")
        else:
            print(f"Flight {fid} not booked for {pid}.")
    return df

# Main Program
flight_data = load_flight_data()
festival_dates = load_festival_dates()
hub_cities = identify_hub_cities(flight_data)

while True:
    print("\nMenu:")
    print("1. Search, Sort & Book Flight")
    print("2. View Hub Cities")
    print("3. Allocate Flights to Multiple Passengers using Bipartite Matching")
    print("4. Exit")
    choice = input("Enter your choice: ").strip()

    if choice == "1":
        date = input("Enter the date (YYYY-MM-DD): ").strip()
        start_city = input("Enter the start city: ").strip()
        end_city = input("Enter the destination city: ").strip()
        flight_data = search_sort_book_flight(flight_data, start_city, end_city, date, festival_dates)

    elif choice == "2":
        print("\nHub Cities (High Traffic Airports):")
        for city in hub_cities:
            print(f"- {city}")
    elif choice == "3":
        flight_data = perform_bipartite_flight_allocation(flight_data)
    elif choice == "4":
        print("Exiting the program.")
        break
    else:
        print("Invalid choice. Please try again.")